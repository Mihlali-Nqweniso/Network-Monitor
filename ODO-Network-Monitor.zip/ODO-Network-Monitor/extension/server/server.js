const express = require('express');
const http = require('http');
const { Server } = require("socket.io");
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public')); 

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const devices = new Map();
const commandQueue = new Map(); 

app.post('/api/heartbeat', (req, res) => {
    const { deviceId, user, type, latency, download, upload } = req.body;
    const now = Date.now();
    
    const existing = devices.get(deviceId) || {};

    // Use existing speed if this is just a heartbeat
    const curDownload = type === 'test_result' ? download : (existing.download || 0);
    const curUpload = type === 'test_result' ? upload : (existing.upload || 0);
    const curLatency = latency !== undefined ? latency : (existing.latency || 0);

    // --- STATUS LOGIC ---
    let status = 'normal';

    if (curDownload > 0) {
        // Speed based status (Persists between tests)
        if (curDownload >= 100) status = 'fast';
        else if (curDownload >= 10) status = 'normal';
        else status = 'critical';
    } else {
        // Fallback only if NO speed test has ever run
        if (curLatency > 400) status = 'critical';
        else if (curLatency > 150) status = 'normal';
        else status = 'fast';
    }

    const deviceData = {
        id: deviceId,
        fullName: user ? user.fullName : (existing.fullName || "Unknown Device"),
        email: user ? user.email : (existing.email || "No Email"),
        lastSeen: now,
        status: status, 
        latency: curLatency,
        download: curDownload,
        upload: curUpload,
        lastUpdateType: type 
    };

    console.log(`Update ${deviceId} [${type}]: ${status} (DL: ${curDownload})`);

    devices.set(deviceId, deviceData);
    io.emit('device_update', deviceData);

    const pendingCommand = commandQueue.get(deviceId);
    if (pendingCommand) {
        commandQueue.delete(deviceId);
        return res.json({ status: 'ok', command: pendingCommand });
    }
    
    res.json({ status: 'ok' });
});

io.on('connection', (socket) => {
    socket.emit('initial_state', Array.from(devices.values()));
    socket.on('admin_command', (data) => {
        console.log(`Queueing command: ${data.command} for ${data.targetId}`);
        commandQueue.set(data.targetId, data.command);
    });
});

setInterval(() => {
    const now = Date.now();
    devices.forEach((data, id) => {
        if (now - data.lastSeen > 35000 && data.status !== 'offline') {
            data.status = 'offline';
            data.latency = 0;
            devices.set(id, data);
            io.emit('device_offline', { id: id });
        }
    });
}, 5000);

server.listen(3000, () => console.log('🚀 Server running on port 3000'));