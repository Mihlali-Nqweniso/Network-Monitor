const socket = io();
const grid = document.getElementById('device-grid');
const countEl = document.getElementById('device-count');

let activeTestId = null;
let currentFilter = 'all';

function updateCard(data) {
    try {
        if(grid.innerText.includes("Waiting")) grid.innerHTML = "";
        if(!document.getElementById('empty-state')) {
            grid.innerHTML += `<div id="empty-state" style="display:none; width:100%; text-align:center; padding:40px; color:#999;">No devices match.</div>`;
        }

        let card = document.getElementById(`dev-${data.id}`);
        
        if (!card) {
            card = document.createElement('div');
            card.id = `dev-${data.id}`;
            card.className = 'device-card';
            card.onclick = (e) => toggleCard(card, e);
            grid.appendChild(card);
        }

        // --- NEW: Strict Stop Condition ---
        // Only stop the spinner if we have valid speeds for BOTH DL and UL
        if (activeTestId === data.id && shouldStopTest(data)) {
            resetTestButton(data.id);
        }

        // Filter Attributes
        const safeStatus = (data.status || 'normal').toLowerCase();
        card.dataset.status = safeStatus; 
        card.dataset.search = (data.fullName + " " + data.id).toLowerCase();

        const isExpanded = card.classList.contains('expanded');

        // Display Logic
        const dl = data.download ? Number(data.download).toFixed(1) : "--";
        const ul = data.upload ? Number(data.upload).toFixed(1) : "--";
        const ping = data.latency !== undefined ? data.latency : "--";

        const timeAgo = Math.floor((Date.now() - data.lastSeen) / 1000);
        const timeText = timeAgo < 60 ? `${timeAgo}s ago` : `${Math.floor(timeAgo/60)}m ago`;

        // Color Logic
        let dlColor = '#ef4444'; // Red
        const val = data.download || 0;
        if (val >= 100) dlColor = '#10b981'; // Green
        else if (val >= 10) dlColor = '#f59e0b'; // Amber

        card.innerHTML = `
            <div class="status-bar status-${safeStatus}"></div>
            
            <div class="card-header">
                <div class="user-name" title="${data.email}">${data.fullName || 'Unknown'}</div>
                <div class="latency-badge">${ping} ms</div>
            </div>

            <div class="details-panel">
                <div class="metrics-grid">
                    <div>
                        <div class="metric-val" style="color:${dlColor};">${dl}</div>
                        <div class="metric-lbl">Download</div>
                    </div>
                    <div>
                        <div class="metric-val" style="color:#555;">${ul}</div>
                        <div class="metric-lbl">Upload</div>
                    </div>
                </div>
                
                <div class="meta-row">
                    ID: ${data.id.substring(0,8)} • Updated ${timeText}
                </div>
                
                <button id="btn-${data.id}" class="btn-test" onclick="runTest('${data.id}', this, event)">
                    Run Speed Test
                </button>
            </div>
        `;
        
        if (isExpanded) card.classList.add('expanded');
        
        applyFilterToCard(card);
        updateCount();

    } catch(e) { console.error(e); }
}

// --- NEW: Validation Function ---
function shouldStopTest(data) {
    // 1. Must be a finished test result
    if (data.lastUpdateType !== 'test_result') return false;
    
    // 2. Must have valid non-zero values for both
    // This prevents stopping if the test failed or returned nulls
    const validDL = typeof data.download === 'number' && data.download > 0;
    const validUL = typeof data.upload === 'number' && data.upload > 0;
    
    return validDL && validUL;
}

// --- FILTERING ---
function setFilter(status, btn) {
    currentFilter = status;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    filterGrid();
}

function filterGrid() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;
    const searchVal = searchInput.value.toLowerCase();
    const cards = document.querySelectorAll('.device-card');
    let visibleCount = 0;

    cards.forEach(card => {
        const matchesSearch = (card.dataset.search || "").includes(searchVal);
        const matchesFilter = currentFilter === 'all' || card.dataset.status === currentFilter;
        
        if (matchesSearch && matchesFilter) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });

    const emptyEl = document.getElementById('empty-state');
    if(emptyEl) emptyEl.style.display = visibleCount === 0 ? 'block' : 'none';
    updateCount();
}

function applyFilterToCard(card) {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return; 
    const searchVal = searchInput.value.toLowerCase();
    const matchesSearch = (card.dataset.search || "").includes(searchVal);
    const matchesFilter = currentFilter === 'all' || card.dataset.status === currentFilter;
    card.style.display = (matchesSearch && matchesFilter) ? 'block' : 'none';
}

function toggleCard(card, event) {
    if (event.target.tagName === 'BUTTON') return;
    document.querySelectorAll('.device-card.expanded').forEach(c => {
        if (c !== card) c.classList.remove('expanded');
    });
    card.classList.toggle('expanded');
}

function runTest(deviceId, btn, event) {
    event.stopPropagation();
    btn.disabled = true;
    btn.innerText = "Running...";
    activeTestId = deviceId;
    
    // Trigger command - We rely entirely on shouldStopTest() to reset this
    socket.emit('admin_command', { targetId: deviceId, command: 'run_test' });
}

function resetTestButton(id) {
    const btn = document.getElementById(`btn-${id}`);
    if (btn) {
        btn.disabled = false;
        btn.innerText = "Run Speed Test";
        activeTestId = null;
    }
}

function updateCount() {
    const visible = Array.from(document.querySelectorAll('.device-card'))
        .filter(c => c.style.display !== 'none').length;
    countEl.innerText = visible;
}

socket.on('initial_state', (list) => { if(list.length) { grid.innerHTML = ""; list.forEach(updateCard); } });
socket.on('device_update', (data) => updateCard(data));
socket.on('device_offline', (data) => {
    const card = document.getElementById(`dev-${data.id}`);
    if (card) {
        card.dataset.status = 'offline';
        card.querySelector('.status-bar').className = `status-bar status-offline`;
        card.querySelector('.latency-badge').innerText = "OFFLINE";
        applyFilterToCard(card);
    }
});