const socket = io();
const grid = document.getElementById('device-grid');
const countEl = document.getElementById('device-count');

let activeTestId = null;
let currentFilter = 'all';

function updateCard(data) {
    try {
        if(grid.innerText.includes("Waiting")) grid.innerHTML = "";
        if(!document.getElementById('empty-state')) {
            grid.innerHTML += `<div id="empty-state" style="display:none; width:100%; text-align:center; padding:40px; color:#999;">No devices match.</div>`;
        }

        let card = document.getElementById(`dev-${data.id}`);
        
        if (!card) {
            card = document.createElement('div');
            card.id = `dev-${data.id}`;
            card.className = 'device-card';
            card.onclick = (e) => toggleCard(card, e);
            grid.appendChild(card);
        }

        // Setup attributes for filtering
        const safeStatus = (data.status || 'normal').toLowerCase();
        card.dataset.status = safeStatus; 
        card.dataset.search = (data.fullName + " " + data.id).toLowerCase();

        // ONLY stop spinner if we get a FINAL result (ignore progress updates)
        if (activeTestId === data.id && shouldStopTest(data)) {
            resetTestButton(data.id);
        }

        const isExpanded = card.classList.contains('expanded');

        const dl = (typeof data.download === 'number') ? data.download.toFixed(1) : "--";
        const ul = (typeof data.upload === 'number') ? data.upload.toFixed(1) : "--";
        const ping = data.latency !== undefined ? data.latency : "--";

        const timeAgo = Math.floor((Date.now() - data.lastSeen) / 1000);
        const timeText = timeAgo < 60 ? `${timeAgo}s ago` : `${Math.floor(timeAgo/60)}m ago`;

        // Color Logic
        let dlColor = '#ef4444'; 
        const val = data.download || 0;
        if (val >= 100) dlColor = '#10b981'; 
        else if (val >= 10) dlColor = '#f59e0b'; 

        card.innerHTML = `
            <div class="status-bar status-${safeStatus}"></div>
            
            <div class="card-header">
                <div class="user-name" title="${data.email}">${data.fullName || 'Unknown'}</div>
                <div class="latency-badge">${ping} ms</div>
            </div>

            <div class="details-panel">
                <div class="metrics-grid">
                    <div>
                        <div class="metric-val" style="color:${dlColor};">${dl}</div>
                        <div class="metric-lbl">Download</div>
                    </div>
                    <div>
                        <div class="metric-val" style="color:#555;">${ul}</div>
                        <div class="metric-lbl">Upload</div>
                    </div>
                </div>
                
                <div class="meta-row">
                    ID: ${data.id.substring(0,8)} • Updated ${timeText}
                </div>
                
                <button id="btn-${data.id}" class="btn-test" onclick="runTest('${data.id}', this, event)">
                    ${activeTestId === data.id ? "Testing..." : "Run Speed Test"}
                </button>
            </div>
        `;
        
        if (isExpanded) card.classList.add('expanded');
        
        applyFilterToCard(card);
        updateCount();

    } catch(e) { console.error(e); }
}

function shouldStopTest(data) {
    if (data.lastUpdateType !== 'test_result') return false;
    return (data.download > 0.1 && data.upload > 0.1);
}

// --- FILTERING ---
function setFilter(status, btn) {
    currentFilter = status;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    filterGrid();
}

function filterGrid() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;
    const searchVal = searchInput.value.toLowerCase();
    const cards = document.querySelectorAll('.device-card');
    let visibleCount = 0;

    cards.forEach(card => {
        const matchesSearch = (card.dataset.search || "").includes(searchVal);
        const matchesFilter = currentFilter === 'all' || card.dataset.status === currentFilter;
        
        if (matchesSearch && matchesFilter) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });

    const emptyEl = document.getElementById('empty-state');
    if(emptyEl) emptyEl.style.display = visibleCount === 0 ? 'block' : 'none';
    updateCount();
}

function applyFilterToCard(card) {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return; 
    const searchVal = searchInput.value.toLowerCase();
    const matchesSearch = (card.dataset.search || "").includes(searchVal);
    const matchesFilter = currentFilter === 'all' || card.dataset.status === currentFilter;
    card.style.display = (matchesSearch && matchesFilter) ? 'block' : 'none';
}

function toggleCard(card, event) {
    if (event.target.tagName === 'BUTTON') return;
    document.querySelectorAll('.device-card.expanded').forEach(c => {
        if (c !== card) c.classList.remove('expanded');
    });
    card.classList.toggle('expanded');
}

function runTest(deviceId, btn, event) {
    event.stopPropagation();
    activeTestId = deviceId;
    const btnEl = document.getElementById(`btn-${deviceId}`);
    if(btnEl) {
        btnEl.disabled = true;
        btnEl.innerText = "Testing...";
    }
    socket.emit('admin_command', { targetId: deviceId, command: 'run_test' });
}

function resetTestButton(id) {
    const btn = document.getElementById(`btn-${id}`);
    if (btn) {
        btn.disabled = false;
        btn.innerText = "Run Speed Test";
        activeTestId = null;
    }
}

function updateCount() {
    const visible = Array.from(document.querySelectorAll('.device-card'))
        .filter(c => c.style.display !== 'none').length;
    countEl.innerText = visible;
}

socket.on('initial_state', (list) => { if(list.length) { grid.innerHTML = ""; list.forEach(updateCard); } });
socket.on('device_update', (data) => updateCard(data));
socket.on('device_offline', (data) => {
    const card = document.getElementById(`dev-${data.id}`);
    if (card) {
        card.dataset.status = 'offline';
        card.querySelector('.status-bar').className = `status-bar status-offline`;
        card.querySelector('.latency-badge').innerText = "OFFLINE";
        applyFilterToCard(card);
    }
});