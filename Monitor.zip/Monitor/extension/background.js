const CONFIG = {
    // --- UPDATED: YOUR SPECIFIC IP ADDRESS ---
    SERVER_URL: "http://192.168.201.18:3000/api/heartbeat", 
    
    POLL_INTERVAL_MINUTES: 0.16, // Poll every ~10s
    AUTO_TEST_INTERVAL_MS: 60 * 60 * 1000, // 1 Hour Auto-Test
    BASE_URL: "https://speed.cloudflare.com",
    TEST_DURATION_MS: 10000 // 10s per phase
};

let lastAutoTestTime = 0;

// --- Identity & State ---
async function getUserIdentity() {
    return new Promise((resolve) => {
        chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (userInfo) => {
            if (chrome.runtime.lastError || !userInfo.email) {
                chrome.storage.local.get("cached_user", (data) => {
                    resolve(data.cached_user || { fullName: "Unknown Device", email: "No Auth" });
                });
            } else {
                const profile = { fullName: parseNameFromEmail(userInfo.email), email: userInfo.email };
                chrome.storage.local.set({ "cached_user": profile });
                resolve(profile);
            }
        });
    });
}

function parseNameFromEmail(email) {
    try {
        if (!email || !email.includes('@')) return "Unknown";
        const localPart = email.split('@')[0];
        const parts = localPart.split('.');
        return parts.map(part => 
            part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()
        ).join(' ');
    } catch (e) { return email; }
}

async function getDeviceId() {
    const data = await chrome.storage.local.get("device_id");
    if (data.device_id) return data.device_id;
    const newId = crypto.randomUUID();
    await chrome.storage.local.set({ device_id: newId });
    return newId;
}

// --- Scheduler ---
chrome.runtime.onInstalled.addListener(() => setupAlarm());
chrome.runtime.onStartup.addListener(() => setupAlarm());

function setupAlarm() {
    chrome.alarms.get("network_pulse", (a) => {
        if (!a) chrome.alarms.create("network_pulse", { periodInMinutes: CONFIG.POLL_INTERVAL_MINUTES });
    });
    checkCycle();
}

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "network_pulse") checkCycle();
});

// --- 1. Cycle Logic ---
async function checkCycle() {
    const deviceId = await getDeviceId();
    const user = await getUserIdentity();
    const now = Date.now();

    // A. Auto Test (Every 1 Hour)
    if (now - lastAutoTestTime > CONFIG.AUTO_TEST_INTERVAL_MS) {
        console.log("⏰ Auto Test Triggered");
        lastAutoTestTime = now;
        await runRobustTest(deviceId, user, false);
        return;
    }

    // B. Poll (Lightweight Heartbeat)
    try {
        const start = performance.now();
        await fetch(`${CONFIG.BASE_URL}/__down?bytes=0`, { method: 'HEAD', cache: 'no-store' });
        const latency = Math.round(performance.now() - start);
        await sendTelemetry(deviceId, user, { type: 'heartbeat', latency });
    } catch (e) {}
}

// --- 2. Robust Tester ---
async function runRobustTest(deviceId, user, isManual) {
    console.log("🚀 Starting Speed Test...");
    let results = { download: 0, upload: 0 };
    let success = false;
    let attempts = 0;
    
    // Live Progress Callback
    const onProgress = async (partialResults) => {
        await sendTelemetry(deviceId, user, {
            type: 'test_progress', 
            latency: 0, 
            download: parseFloat(partialResults.download) || 0,
            upload: parseFloat(partialResults.upload) || 0
        });
    };

    // Retry Logic
    const maxAttempts = isManual ? 50 : 2;

    while(!success && attempts < maxAttempts) {
        attempts++;
        try {
            const tester = new SpeedTester();
            results = await tester.run(onProgress);
            
            // Validation
            if (parseFloat(results.download) > 0.1 && parseFloat(results.upload) > 0.1) {
                success = true;
            } else {
                await new Promise(r => setTimeout(r, 2000));
            }
        } catch (e) {
            console.error("Test Error", e);
            await new Promise(r => setTimeout(r, 2000));
        }
    }

    // Measure final latency
    let latency = 0;
    try {
        const start = performance.now();
        await fetch(`${CONFIG.BASE_URL}/__down?bytes=0`, { method: 'HEAD', cache: 'no-store' });
        latency = Math.round(performance.now() - start);
    } catch(e){}

    // Send Final Result
    await sendTelemetry(deviceId, user, { 
        type: 'test_result', 
        latency: latency,
        download: parseFloat(results.download) || 0,
        upload: parseFloat(results.upload) || 0
    });
}

// --- 3. Speed Logic (Time Based) ---
class SpeedTester {
    constructor() { this.results = { download: 0, upload: 0 }; }

    async run(onProgress) {
        this.results.download = await this.measurePhase('download', CONFIG.TEST_DURATION_MS, onProgress);
        this.results.upload = await this.measurePhase('upload', CONFIG.TEST_DURATION_MS, onProgress);

        this.results.download = this.results.download.toFixed(2);
        this.results.upload = this.results.upload.toFixed(2);
        return this.results;
    }

    async measurePhase(type, duration, onProgress) {
        const startTime = performance.now();
        const endTime = startTime + duration;
        let totalBytes = 0;
        let currentChunkSize = 1000000; // 1MB start
        let lastReport = 0;

        while (performance.now() < endTime) {
            try {
                const chunkStart = performance.now();
                if (type === 'download') await this.fetchDownload(currentChunkSize);
                else await this.fetchUpload(currentChunkSize);
                
                const now = performance.now();
                const chunkTime = now - chunkStart;
                if(chunkTime > 0) totalBytes += currentChunkSize;

                // Live Report (Throttle 800ms)
                if (onProgress && (now - lastReport > 800)) {
                    const currentSpeed = (totalBytes * 8) / ((now - startTime) / 1000) / 1000000;
                    if(type === 'download') this.results.download = currentSpeed.toFixed(2);
                    else this.results.upload = currentSpeed.toFixed(2);
                    onProgress(this.results);
                    lastReport = now;
                }

                // Dynamic Scaling
                if (chunkTime < 500 && currentChunkSize < 50000000) currentChunkSize *= 2;

            } catch (e) { await new Promise(r => setTimeout(r, 200)); }
        }

        const totalTimeSec = (performance.now() - startTime) / 1000;
        return (totalBytes * 8) / totalTimeSec / 1000000;
    }

    async fetchDownload(bytes) {
        const res = await fetch(`${CONFIG.BASE_URL}/__down?bytes=${bytes}`, { cache: 'no-store' });
        if(!res.ok) throw new Error("DL Err");
        await res.blob();
    }

    async fetchUpload(bytes) {
        const data = new Uint8Array(bytes);
        const res = await fetch(`${CONFIG.BASE_URL}/__up`, { method: 'POST', body: data, cache: 'no-store' });
        if(!res.ok) throw new Error("UL Err");
    }
}

async function sendTelemetry(deviceId, user, data) {
    try {
        const response = await fetch(CONFIG.SERVER_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ deviceId, user, ...data })
        });
        
        if (response.ok) {
            const reply = await response.json();
            if (reply.command === 'run_test') {
                console.log("⚡ Manual Command");
                await runRobustTest(deviceId, user, true);
            }
        }
    } catch (e) {}
}